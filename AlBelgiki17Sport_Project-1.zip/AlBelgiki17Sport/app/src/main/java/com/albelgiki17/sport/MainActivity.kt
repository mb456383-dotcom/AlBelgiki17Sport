package com.albelgiki17.sport

import android.app.Activity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*
import org.json.JSONObject
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private val green = Color.rgb(33, 220, 120)
    private val bg = Color.rgb(12, 17, 20)
    private val panel = Color.rgb(24, 32, 35)
    private val white = Color.WHITE
    private val muted = Color.rgb(177, 190, 190)
    private val executor = Executors.newSingleThreadExecutor()
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var body: LinearLayout
    private lateinit var status: TextView
    private var token = ""
    private var competition = "PL"
    private var selectedTab = "matches"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        token = getPreferences(MODE_PRIVATE).getString("api_token", "") ?: ""
        buildShell()
        showMatches()
    }

    private fun buildShell() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 22, 20, 16)
            setBackgroundColor(Color.rgb(16, 25, 25))
        }
        header.addView(TextView(this).apply {
            text = "⚽ البلجيكي 17 سبورت"
            textSize = 25f
            setTextColor(green)
            gravity = Gravity.CENTER
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        })
        header.addView(TextView(this).apply {
            text = "نتائج • مباريات • ترتيب الدوريات"
            textSize = 13f
            setTextColor(muted)
            gravity = Gravity.CENTER
            setPadding(0, 7, 0, 0)
        })
        root.addView(header)
        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(6, 8, 6, 8)
        }
        nav.addView(navButton("المباريات") { selectedTab = "matches"; showMatches() }, weight())
        nav.addView(navButton("الترتيب") { selectedTab = "standings"; showStandings() }, weight())
        nav.addView(navButton("الإعدادات") { selectedTab = "settings"; showSettings() }, weight())
        root.addView(nav)
        status = TextView(this).apply {
            setTextColor(muted); textSize = 12f; gravity = Gravity.CENTER
            setPadding(12, 4, 12, 8)
        }
        root.addView(status)
        val scroll = ScrollView(this)
        body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(14, 8, 14, 24)
        }
        scroll.addView(body)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun weight() = LinearLayout.LayoutParams(0, -2, 1f)

    private fun navButton(label: String, action: () -> Unit): Button =
        Button(this).apply {
            text = label
            textSize = 12f
            setTextColor(white)
            setBackgroundTintList(android.content.res.ColorStateList.valueOf(panel))
            setOnClickListener { action() }
        }

    private fun reset(title: String, subtitle: String = "") {
        body.removeAllViews()
        addText(title, 22f, green, true, 0, 8)
        if (subtitle.isNotBlank()) addText(subtitle, 13f, muted, false, 0, 12)
    }

    private fun addText(text: String, size: Float = 15f, color: Int = white,
                        bold: Boolean = false, top: Int = 0, bottom: Int = 6) {
        body.addView(TextView(this).apply {
            this.text = text; textSize = size; setTextColor(color)
            if (bold) typeface = android.graphics.Typeface.DEFAULT_BOLD
            setPadding(4, top, 4, bottom)
        })
    }

    private fun addCard(text: String) {
        val card = TextView(this).apply {
            this.text = text
            textSize = 15f
            setTextColor(white)
            setPadding(15, 15, 15, 15)
            setBackgroundColor(panel)
        }
        val p = LinearLayout.LayoutParams(-1, -2)
        p.bottomMargin = 10
        body.addView(card, p)
    }

    private fun requireTokenOrSettings() {
        if (token.isBlank()) {
            status.text = "أضف مفتاح API من الإعدادات لتظهر البيانات الحقيقية."
            showSettings()
        }
    }

    private fun showMatches() {
        reset("مباريات كرة القدم", "اختر البطولة ثم اضغط تحديث. البيانات تأتي من football-data.org.")
        val spinner = Spinner(this)
        val labels = listOf("الدوري الإنجليزي" to "PL", "الدوري الإسباني" to "PD",
            "الدوري الألماني" to "BL1", "الدوري الإيطالي" to "SA", "دوري أبطال أوروبا" to "CL")
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, labels.map { it.first })
        spinner.setSelection(labels.indexOfFirst { it.second == competition }.coerceAtLeast(0))
        spinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                competition = labels[position].second
            }
        }
        body.addView(spinner)
        val row = LinearLayout(this)
        row.addView(navButton("تحديث المباريات") { loadMatches() }, weight())
        row.addView(navButton("مباريات اليوم") { loadToday() }, weight())
        body.addView(row)
        addText("ملحوظة: البطولات المتاحة تعتمد على باقة حساب API.", 12f, muted, false, 8, 8)
        if (token.isBlank()) addText("افتح الإعدادات والصق مفتاح API المجاني أو المدفوع.", 14f, white)
        else loadMatches()
    }

    private fun showStandings() {
        reset("ترتيب الدوري", "جدول الترتيب الحالي حسب البطولة المتاحة في حساب API.")
        val labels = listOf("الدوري الإنجليزي" to "PL", "الدوري الإسباني" to "PD",
            "الدوري الألماني" to "BL1", "الدوري الإيطالي" to "SA")
        val spinner = Spinner(this)
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, labels.map { it.first })
        spinner.setSelection(labels.indexOfFirst { it.second == competition }.coerceAtLeast(0))
        spinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) { competition = labels[position].second }
        }
        body.addView(spinner)
        body.addView(navButton("تحديث الترتيب") { loadStandings() })
        if (token.isBlank()) addText("أضف مفتاح API من الإعدادات أولًا.")
        else loadStandings()
    }

    private fun showSettings() {
        reset("الإعدادات", "مصدر البيانات: football-data.org API")
        addText("1) أنشئ حسابًا في موقع football-data.org واحصل على مفتاح API. راجع البطولات المتاحة في باقتك.", 15f, white)
        val link = navButton("فتح موقع مصدر البيانات") { startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse("https://www.football-data.org/"))) }
        body.addView(link)
        addText("2) الصق المفتاح هنا. لا تنشره مع صور أو فيديوهات، ولا تضعه في كود عام.", 14f, muted, false, 12, 6)
        val input = EditText(this).apply {
            hint = "مفتاح API"
            setHintTextColor(muted); setTextColor(white)
            setSingleLine(true)
            setText(token)
            setPadding(12, 12, 12, 12)
            setBackgroundColor(panel)
        }
        body.addView(input)
        body.addView(navButton("حفظ المفتاح") {
            token = input.text.toString().trim()
            getPreferences(MODE_PRIVATE).edit().putString("api_token", token).apply()
            status.text = if (token.isBlank()) "لم يتم إدخال مفتاح." else "تم حفظ المفتاح على هذا الجهاز."
            showMatches()
        })
        addText("تنبيه أمان: هذا نموذج أولي يرسل المفتاح من الهاتف مباشرة إلى مزود البيانات. للتطبيق المنشور على نطاق واسع، الأفضل استخدام خادم وسيط يحمي المفتاح.", 13f, muted, false, 12, 6)
        addText("الإصدار 1.0 • البلجيكي 17 سبورت", 12f, green, false, 12, 6)
    }

    private fun loadToday() {
        val date = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
        fetch("/matches?dateFrom=$date&dateTo=$date") { json -> renderMatches(json.optJSONArray("matches")) }
    }

    private fun loadMatches() {
        fetch("/competitions/$competition/matches?limit=30") { json -> renderMatches(json.optJSONArray("matches")) }
    }

    private fun renderMatches(matches: JSONArray?) {
        body.removeAllViews()
        addText("المباريات", 22f, green, true, 0, 10)
        if (matches == null || matches.length() == 0) {
            addText("لا توجد مباريات في الرد الحالي، أو أن البطولة غير متاحة في باقتك.", 15f, muted)
            return
        }
        for (i in 0 until matches.length()) {
            val m = matches.optJSONObject(i) ?: continue
            val home = m.optJSONObject("homeTeam")?.optString("name", "الفريق الأول") ?: "الفريق الأول"
            val away = m.optJSONObject("awayTeam")?.optString("name", "الفريق الثاني") ?: "الفريق الثاني"
            val score = m.optJSONObject("score")?.optJSONObject("fullTime")
            val goals = if (score == null || score.isNull("home")) "لم تبدأ" else "${score.optString("home")} - ${score.optString("away")}"
            val date = m.optString("utcDate", "").replace("T", " ").take(16)
            val statusText = when (m.optString("status")) {
                "FINISHED" -> "انتهت"
                "IN_PLAY", "LIVE", "PAUSED" -> "مباشرة/جارية"
                "SCHEDULED", "TIMED" -> "قادمة"
                else -> m.optString("status", "غير معروف")
            }
            addCard("$home\n$goals\n$away\n$date UTC • $statusText")
        }
    }

    private fun loadStandings() {
        fetch("/competitions/$competition/standings") { json ->
            body.removeAllViews()
            addText("ترتيب الدوري", 22f, green, true, 0, 10)
            val standings = json.optJSONArray("standings")
            val table = standings?.optJSONObject(0)?.optJSONArray("table")
            if (table == null) {
                addText("الترتيب غير متاح لهذه البطولة أو في باقتك.", 15f, muted)
                return@fetch
            }
            addCard("المركز | الفريق | لعب | له | عليه | نقاط")
            for (i in 0 until table.length()) {
                val t = table.optJSONObject(i) ?: continue
                addCard("${t.optInt("position")} | ${t.optJSONObject("team")?.optString("name", "فريق")}\nلعب ${t.optInt("playedGames")} • له ${t.optInt("goalsFor")} • عليه ${t.optInt("goalsAgainst")} • نقاط ${t.optInt("points")}")
            }
        }
    }

    private fun fetch(path: String, onSuccess: (JSONObject) -> Unit) {
        if (token.isBlank()) { showSettings(); return }
        status.text = "جاري تحميل البيانات..."
        executor.execute {
            var connection: HttpURLConnection? = null
            try {
                connection = (URL("https://api.football-data.org/v4$path").openConnection() as HttpURLConnection).apply {
                    requestMethod = "GET"
                    connectTimeout = 15000
                    readTimeout = 15000
                    setRequestProperty("X-Auth-Token", token)
                    setRequestProperty("Accept", "application/json")
                }
                val code = connection.responseCode
                val stream = if (code in 200..299) connection.inputStream else connection.errorStream
                val text = stream.bufferedReader().use { it.readText() }
                if (code !in 200..299) throw Exception("خطأ API ($code): " + when(code) {
                    401, 403 -> "المفتاح غير صحيح أو ليس لديك صلاحية لهذه البطولة."
                    429 -> "تم تجاوز حد الطلبات. انتظر قليلًا ثم حاول."
                    else -> text.take(180)
                })
                val json = JSONObject(text)
                handler.post {
                    status.text = "تم التحديث: " + SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
                    onSuccess(json)
                }
            } catch (e: Exception) {
                handler.post {
                    status.text = "تعذر التحديث: ${e.message ?: "تحقق من الإنترنت والمفتاح"}"
                }
            } finally { connection?.disconnect() }
        }
    }

    override fun onDestroy() {
        executor.shutdownNow()
        super.onDestroy()
    }
}
