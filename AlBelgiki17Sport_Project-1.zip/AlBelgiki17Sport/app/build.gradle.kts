plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.albelgiki17.sport"
    compileSdk = 36
    defaultConfig {
        applicationId = "com.albelgiki17.sport"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
